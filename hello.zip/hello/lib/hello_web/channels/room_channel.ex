defmodule HelloWeb.RoomChannel do
    use Phoenix.Channel

    def join("room:lobby", _payload, socket) do
        Process.flag(:trap_exit, true)
        # IO.puts "received connection request"
        # IO.puts "with socket info " <> inspect(socket)

        {:ok, socket}
    end

    def handle_in("search", %{"query" => body}, socket) do
        IO.puts "body: -------------" <> inspect(body)
        

        s1 = DB.getData(:users, "u123")
        IO.puts "so" <> inspect(socket)
        IO.puts "s1" <> inspect(s1)

        HelloWeb.Endpoint.broadcast "room:u123", "close", %{"result" => body}

        # push s1, "close", %{"query" => body}
        
        # push socket, "close", %{"query" => body}
        # broadcast socket, "close", %{"result" => body}
        # {:reply, {:ok, %{:result => body}}, socket}
        {:noreply, socket}
    end



    # def handle_in("login", %{"query" => body}, socket) do
    #     IO.puts "body: -------------" <> inspect(body)
    #     push socket, "search", %{result: ["found"]}
    #     broadcast! socket, "search", %{"result" => body}
    #     {:noreply, socket}
    # end

    # def handle_out("search", %{result: ["found"]}, socket) do
    #     push socket, "search", %{result: ["found"]}
    # end

    def join("room:u" <> _private_user_id, _payload, socket) do
        Process.flag(:trap_exit, true)
        
        user_id = "u" <> _private_user_id

        # IO.puts user_id <> " came."
        DB.save(:users, user_id, true)
        # DB.save(:user_followers, user_id, [])

        # IO.puts "user logged in " <> inspect(DB.getData(:users, user_id))

        {:ok, socket}
    end

    # def handle_in("follow_users", map, socket) do
        
    # end

    # def handle_in("follow_hashtag", map, socket) do
        
    # end

    def handle_in("login", map, socket) do
        user_id = map["user_id"]
        # IO.puts "user " <> user_id <> " logged in."
        DB.save(:users, user_id, true)
        feed = FeedService.feed(user_id)
        # UserService.sendFeed(user_id, feed)
        {:reply, {:ok,%{"feed" => feed}}, socket}
    end

    def handle_in("logout", map, socket) do
        user_id = map["user_id"]
        DB.delete(:users, user_id)
        {:noreply, socket}
    end

    def handle_in("tweet", map, socket) do
        # IO.puts "tweet---------------" <> map["user_id"] <> "  " <> map["tweet_obj"]["text"]
        user_id = map["user_id"]
        tweet = map["tweet_obj"]
        TweetService.tweet(user_id, tweet)
        {:reply, {:ok, %{}}, socket}
    end

    def handle_in("retweet", map, socket) do
        # IO.puts "retweet---------------" <> map["user_id"] <> "  " <> map["tweet_obj"]["text"]
        user_id = map["user_id"]
        tweet = map["tweet_obj"]
        TweetService.retweet(user_id, tweet)
        {:reply, {:ok, %{}}, socket}
    end
    
    # def handle_in("feed", map, socket) do
    #     user_id = map["user_id"]
    #     feed = FeedService.feed(user_id)
    #     # UserService.sendFeed(user_id, feed)
    #     {:reply, {:ok,%{"feed" => feed}}, socket}
    # end

    def terminate(_msg, socket) do
        # IO.puts inspect(socket.topic) <> " logged out"
        user_id = socket.topic |> String.slice(5..-1)
        # IO.puts user_id
        DB.delete(:users, user_id)
        socket
    end

end