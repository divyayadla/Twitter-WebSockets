defmodule FollowService do

	def followUsers(user_id, followers, c) do
		DB.save(:user_followers, user_id, followers)
	end

	def followHashtag(hashtag, users, c) do
		DB.save(:hashtag_followers, hashtag, users)
	end

	# def unfollowUser(user_id, unfollow_user_id) do
	# 	followers = DB.getData(:user_followers, unfollow_user_id)
	# 	list = Enum.filter(followers, fn(x) -> x != user_id end)
	# 	DB.save(:user_followers, unfollow_user_id, list)
	# 	IO.puts "Succesfully unfollowed " <> inspect(unfollow_user_id)
	# end

	# def unfollowHashtag(user_id, hashtag) do
	# 	followers = DB.getData(:hashtag_followers, hashtag)
	# 	list = Enum.filter(followers, fn(x) -> x != user_id end)
	# 	DB.save(:hashtag_followers, hashtag, list)
	# 	IO.puts "Succesfully unfollowed " <> inspect(hashtag)
	# end

end