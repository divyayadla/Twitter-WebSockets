defmodule HelloWeb.PageView do
  use HelloWeb, :view
end
