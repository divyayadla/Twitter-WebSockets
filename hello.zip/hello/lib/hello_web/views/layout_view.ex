defmodule HelloWeb.LayoutView do
  use HelloWeb, :view
end
