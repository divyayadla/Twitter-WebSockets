defmodule Engine do
    
    use GenServer
  
    def start_link(args) do
      GenServer.start_link(__MODULE__, args, [name: :server])
    end
  
    def start_engine(curr, start_time, f) do
        
        receive do
          {:tweet} -> 
                      if curr == 0 && f do
                        start_time = :os.system_time(:millisecond)
                      end
                      curr = curr + 1;
                      if curr == 100 do
                        stop_time = :os.system_time(:millisecond)
                        t = stop_time - start_time
                        if t > 0 do
                          ts = 100000/t
                          IO.puts "tweets per second is " <> inspect(ts)
                        # else
                        #   IO.puts "div by zero" 
                        #   System.halt
                        end
    
                        # puf()
                        start_engine(0, stop_time, false)
                      else 
                        start_engine(curr, start_time, false)
                      end
        end
    
        # :timer.sleep(2000)
        # IO.inspect Node.list
        # c = DB.getData(:metadata, :tweets_count)
        # IO.inspect "Tweets send in last 10 seconds are " <> to_string(c)
        # start_engine
    end


    def init(args) do
        # IO.puts "In gen server"
      # IO.puts "inside engine init"
      Process.flag(:trap_exit, true)

      :ets.new(:metadata, [:public, :named_table])

      start_distributed_node("master")
      
    DB.save(:metadata, :tweets_count, 0)
    DB.save(:metadata, :curr_users, 0)
    DB.createTable(:users)
    # DB.createTable(:tweets)
    DB.createTable(:user_followers)
    DB.createTable(:hashtag_followers)
    DB.createTable(:feed)
    # IO.puts "In gen server"
    
    # # start gen server
    # {:ok, gen_pid} = Engine.start_link([])

    # register gen server with an atom name
    :global.register_name(:server, self())

    # :global.register_name(:start_val, 1)

    # IO.inspect "registered " <> inspect(f)


    s = :global.whereis_name(:server)
    IO.inspect "name " <> inspect(s)

    DB.save(:metadata, :gen_pid, self())
    # IO.puts "In gen server"
    
    IO.puts "Started twitter engine. Now connect simulators."

    args = [true]
    args = [0 | args]
    args = [0 | args]
    {:ok, print_pid} = Task.start(__MODULE__, :start_engine, args) # start_engine(0, 0, true)

    DB.save(:metadata, :print_pid, print_pid)
    IO.puts "In gen server pp " <> inspect(DB.getData(:metadata, :print_pid))
    

    #   mpid = DB.getData(:metadata, :main_pid)
      {:ok, %{:print_pid => print_pid, :start_val => 1}}
    end
 
    def start_distributed_node(name) do
        unless Node.alive?() do
          str = "@" <> get_ip_address()
          IO.puts name <> str
          {:ok, _} = Node.start(String.to_atom(name<>str), :longnames)
        end
        cookie = :bitcoins
        Node.set_cookie(cookie)
      end
      def get_ip_address do
        ips = :inet.getif() |> elem(1)
        [head | tail] = ips
        valid_ips = check_if_valid(head, tail, [])
        ip =
          if valid_ips == [] do
            elem(head, 0)
          else 
            Enum.at(valid_ips, 0)
          end
        # ip = Enum.at(valid_ips, 0)
        val = to_string(elem(ip, 0)) <> "." <> to_string(elem(ip, 1)) <> "." <> to_string(elem(ip, 2)) <> "." <> to_string(elem(ip, 3))
        val
      end
    
      def check_if_valid(head, tail, ipList) do
        ip_tuple = elem(head, 0)
    
        ipList =
          if !isLocalIp(ip_tuple) do
            if elem(ip_tuple, 0) == 192 || elem(ip_tuple, 0) == 10 || elem(ip_tuple, 0) == 128 do
              [ ip_tuple| ipList]
            else 
              ipList
            end
          else 
            ipList
          end
        
        if tail == [] do
          ipList
        else 
          [new_head | new_tail] = tail
          check_if_valid(new_head, new_tail, ipList)
        end
      end
    
      def isLocalIp(ip_tuple) do
        if elem(ip_tuple, 0) == 127 && elem(ip_tuple, 1) == 0 && elem(ip_tuple, 2) == 0 && elem(ip_tuple, 3) == 1 do
          true
        else 
          false
        end
      end
    
      def connect_to_cluster(name) do
        Node.connect String.to_atom(name)
      end





    


    def start_val(server, n) do
      GenServer.call(server, {:start_val, n})
    end 
  
    def handle_call({:start_val, n}, _from, state) do
      
      st = state[:start_val]
      new_st = st+n
      state = state |> Map.put(:start_val, new_st)
  
      {:reply, st, state}
    end
  
    def register(server, user_map) do
      # IO.puts "inside register"
      GenServer.cast(server, {:register, user_map})
    end
  
    def handle_cast({:register, user_map}, state) do
      # IO.puts "inside register cast"
      UserService.register(user_map)
      {:noreply, state}
    end
  
    def login(server, user_map) do
      GenServer.cast(server, {:login, user_map})
    end
  
    def handle_cast({:login, user_map}, state) do
      UserService.login(user_map)
      {:noreply, state}  
    end
    
    def logout(server, user_map) do
      GenServer.cast(server, {:logout, user_map})
    end
  
    def handle_cast({:logout, user_map}, state) do
      UserService.logout(user_map)
      {:noreply, state}  
    end
  
    def tweet(server, user_id, tweet) do
      # IO.puts "inside tweets"
      GenServer.cast(server, {:tweet, user_id, tweet})
    end
  
    def handle_cast({:tweet, user_id, tweet}, state) do
      # IO.puts "inside tweets cast"
      Process.flag(:trap_exit, true)
      
      # TweetService.tweet(user_id, tweet, state[:main_pid])
      args = [state[:print_pid]]
      args = [ tweet | args]
      args = [ user_id | args]
      Task.start(TweetService, :tweet, args)
      {:noreply, state}  
    end
  
    def retweet(server, user_id, tweet) do
      GenServer.cast(server, {:retweet, user_id, tweet})
    end
  
    def handle_cast({:retweet, user_id, tweet}, state) do
      Process.flag(:trap_exit, true)
      
      # TweetService.retweet(user_id, tweet, state[:main_pid])
      args = [state[:print_pid]]
      args = [ tweet | args]
      args = [ user_id | args]
      Task.start(TweetService, :retweet, args)
  
      {:noreply, state}  
    end
  
    # def follow_user(server, user_id, follow_user_id) do
      
    # end
  
    def follow_users(server, user_id, followers, c) do
      GenServer.cast(server, {:follow_users, user_id, followers, c})
    end
  
    def handle_cast({:follow_users, user_id, followers, c}, state) do
      FollowService.followUsers(user_id, followers, c)
      {:noreply, state}  
    end
  
    def follow_hashtag(server, hashtag, users, c) do
      GenServer.cast(server, {:follow_hashtag, hashtag, users, c})
    end
  
    def handle_cast({:follow_hashtag, hashtag, users, c}, state) do
      FollowService.followHashtag(hashtag, users, c)
      {:noreply, state}  
    end
  
    def unfollow_user(server, user_id, unfollow_user_id) do
      GenServer.cast(server, {:unfollow_user, user_id, unfollow_user_id})
    end
  
    def handle_cast({:unfollow_user, user_id, unfollow_user_id}, state) do
      FollowService.unfollowUser(user_id, unfollow_user_id)
      {:noreply, state}  
    end
  
    def unfollow_hashtag(server, user_id, hashtag) do
      GenServer.cast(server, {:unfollow_hashtag, user_id, hashtag})
    end
  
    def handle_cast({:unfollow_hashtag, user_id, hashtag}, state) do
      FollowService.unfollowHashtag(user_id, hashtag)
      {:noreply, state}  
    end
  
    def getFeed(server, user_id, state) do
      GenServer.cast(server, {:getFeed, user_id})
    end
  
    def handle_cast({:getFeed, user_id}, state) do
      FeedService.feed(user_id)
      {:noreply, state}  
    end
  
  end