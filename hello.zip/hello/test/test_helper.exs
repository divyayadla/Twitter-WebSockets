ExUnit.start()

Ecto.Adapters.SQL.Sandbox.mode(Hello.Repo, :manual)

