defmodule HelloWeb.LayoutViewTest do
  use HelloWeb.ConnCase, async: true
end
