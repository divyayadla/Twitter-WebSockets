defmodule HelloWeb.PageViewTest do
  use HelloWeb.ConnCase, async: true
end
