defmodule SIM do


  def main(args) do
    IO.inspect(self)
    {:ok, pid} = PhoenixChannelClient.start_link()
    
    IO.inspect(pid)

    {:ok, socket} = PhoenixChannelClient.connect(pid,
      host: "localhost",
      path: "/socket/websocket",
      # params: %{token: "something"},
      port: 4000
      # secure: false
      )
    
    channel = PhoenixChannelClient.channel(socket, "room:u123", %{name: "Ryo"})
    
    case PhoenixChannelClient.join(channel) do
      {:ok, socket} -> IO.puts("Connected")
      {:error, %{reason: reason}} -> IO.puts(reason)
      :timeout -> IO.puts("timeout")
    end
    
    PhoenixChannelClient.push(channel, "search", %{query: "Hello"})


    # case PhoenixChannelClient.push_and_receive(channel, "search", %{query: "Elixir"}, 100) do
    #   {:ok, %{result: result}} -> IO.puts "r:" <> inspect(result)  # IO.puts("#\{length(result)} items")
    #   {:ok, %{"result"=> result}} -> IO.puts "r:" <> inspect(result)  # IO.puts("#\{length(result)} items")
      
    #   {:error, %{reason: reason}} -> IO.puts(reason)
    #   :timeout -> IO.puts("timeout")
    # end
    
    IO.puts "here"    
    # :timer.sleep(500)
    
    receive do
      {"new_msg", message} -> IO.puts(message)
      {:close, mesg} -> IO.puts("closed")
      {:error, error} -> IO.puts("wewe")
      {"close", msg} -> IO.puts "closed " <> inspect(self())
      {_} -> IO.puts "heree"
    end
    
    {:ok, ret} = PhoenixChannelClient.leave(channel)
    IO.puts "ret " <> inspect(ret)

  end


end
