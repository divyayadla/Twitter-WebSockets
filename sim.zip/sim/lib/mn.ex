defmodule MN do
    def main(args) do
        Process.flag(:trap_exit, true)
    
        :ets.new(:metadata, [:public, :named_table])
        DB.save(:metadata, :main_pid, self())


        # [ name | args] = args
        name = "client"
        
        [val | args] = args
        start_distributed_node("client")
        connect_to_cluster("master@"<>val)
        DB.save(:metadata, :host_name, val)
        # sync the global data on each node
        :global.sync

        [n | args] = args
        n = elem(Integer.parse(n), 0)
        IO.puts "Starting twitter simulation with " <> to_string(n) <> " users."
        IO.puts "----------------------------------------------------------------------------"

        engine_node = Enum.at(Node.list, 0)
        IO.inspect "engine_node " <> inspect(engine_node)
        
        # get the gen_servr pid of the backend server from global fata
        gen_pid = :global.whereis_name(:server)

        st = 1
        IO.puts "start val is " <> to_string(st)
        ed = st + n - 1

        IO.inspect "master gen_pid is " <> inspect(gen_pid)



        # params = [n]
        # Node.spawn(engine_node ,EngineListener, :initialize, params)


        # [st | args] = args 

        # st = elem(Integer.parse(st), 0)

        # [ed | args] = args
        # ed = elem(Integer.parse(ed), 0)

        args = [ed]
        args = [st | args]
        args = [n | args]
        args = [gen_pid | args]
        args = [engine_node | args]
        args = [name | args]
        {:ok, gen_pid} = Simulator.start_link(args)
        DB.save(:metadata, :gen_pid, gen_pid)
        start_simulation(args)


    end

    def start_simulation(state) do
        receive do
          {:print, text} -> IO.inspect text
                              start_simulation(state)
          {:login, engine_node, engine_gen_pid, user_id, curr, gen_pid, n, name} -> 
                              args = [name]
                              args = [n | args]
                              args = [gen_pid | args]
                              args = [curr | args]
                              args = [user_id | args]
                              args = [engine_gen_pid | args]
                              args = [engine_node | args]
                              
                              Process.flag(:trap_exit, true)
                              
                              {_, pid} = Task.start(Client, :login, args)
                              start_simulation(state)
          {:exit} -> IO.inspect "Exiting the simulation"
        end
    end

    
    def start_distributed_node(name) do
        unless Node.alive?() do
            str = "@" <> get_ip_address()
            IO.puts name <> str
            {:ok, _} = Node.start(String.to_atom(name<>str), :longnames)
        end
        cookie = :bitcoins
        Node.set_cookie(cookie)
    end
    
    def get_ip_address do
        ips = :inet.getif() |> elem(1)
        [head | tail] = ips
        valid_ips = check_if_valid(head, tail, [])
        ip =
            if valid_ips == [] do
                elem(head, 0)
            else 
                Enum.at(valid_ips, 0)
            end
        # ip = Enum.at(valid_ips, 0)
        val = to_string(elem(ip, 0)) <> "." <> to_string(elem(ip, 1)) <> "." <> to_string(elem(ip, 2)) <> "." <> to_string(elem(ip, 3))
        val
    end

    def check_if_valid(head, tail, ipList) do
        ip_tuple = elem(head, 0)

        ipList =
            if !isLocalIp(ip_tuple) do
                if elem(ip_tuple, 0) == 192 || elem(ip_tuple, 0) == 10 || elem(ip_tuple, 0) == 128 do
                    [ ip_tuple| ipList]
                else 
                    ipList
                end
            else 
                ipList
            end
        
        if tail == [] do
            ipList
        else 
            [new_head | new_tail] = tail
            check_if_valid(new_head, new_tail, ipList)
        end
    end

    def isLocalIp(ip_tuple) do
        if elem(ip_tuple, 0) == 127 && elem(ip_tuple, 1) == 0 && elem(ip_tuple, 2) == 0 && elem(ip_tuple, 3) == 1 do
            true
        else 
            false
        end
    end

    def connect_to_cluster(name) do
        Node.connect String.to_atom(name)
    end
    

end