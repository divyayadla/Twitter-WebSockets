defmodule Client do
	
	def register(engine_node, engine_gen_pid, user_id, curr, gen_pid, n, name) do
		password = hash_sha256(user_id)
		# user_map = %{:user_id => user_id, :password => password, :client_node => Node.self, 
		# 			 :client_gen_pid => gen_pid, :user_pid => self(), :node_name => name}
		
		# args = [user_map]
        # args = [engine_gen_pid | args]
        
        channel = get_channel(user_id)
        
        state = %{#:engine_node => engine_node, :engine_gen_pid => engine_gen_pid, :gen_pid => gen_pid,
        :user_id => user_id, :password => password, :id => curr, :total_users=> n, :channel => channel}

		# Node.spawn(engine_node, Engine, :register, args)
		IO.puts user_id <> " registered."
        # follow_users(user_id)
        :timer.sleep(20000)
		run(state)
    end
    

	def login(engine_node, engine_gen_pid, user_id, curr, gen_pid, n, name) do
		password = hash_sha256(user_id)
		# user_map = %{:user_id => user_id, :password => password, :client_node => Node.self, 
		# 			 :client_gen_pid => gen_pid, :user_pid => self(), :node_name => name}

        # args = [user_map]
		# args = [engine_gen_pid | args]

        channel = get_channel(user_id)

        state = %{#:engine_node => engine_node, :engine_gen_pid => engine_gen_pid, 
        :user_id => user_id, :password => password, :id => curr, :total_users=> n, :channel => channel}

        # Node.spawn(engine_node, Engine, :login, args)
		IO.puts user_id <> " logged in."
        # send self(), {:start_tweeting, true}

        case PhoenixChannelClient.push_and_receive(state[:channel], "feed", %{"user_id" => user_id}, 100) do
            {:ok, %{"feed" => feed}} -> 
                # if feed != [] do
                #     IO.puts "------------------------------------------------------------nor 0"
                # end
                Process.flag(:trap_exit, true)
                args = [state]
                ts = :rand.uniform(50)
                args = [ts | args]
                args = [self() | args]
                Task.start(__MODULE__, :tweet, args)
                text = "Querying the server for feed for user " <> state[:user_id] <> ". Showing the latest 5 tweeets.. "
                text = concat(feed, 5, text)
                IO.puts text
                
                process(100, feed)
            {:error, %{"reason" => reason}} -> IO.puts(reason)
            :timeout -> a = 1#IO.puts("timeout")
        end
        send self(), {:start_tweeting, true}
		run(state)
	end

	def login_helper(state, user_id) do
		password = hash_sha256(user_id)

		channel = state[:channel]

		IO.puts user_id <> " logged in."

		# PhoenixChannelClient.push(channel, "login", %{"user_id" => user_id})

		# PhoenixChannelClient.push(channel, "feed", %{"user_id" => user_id})

        case PhoenixChannelClient.push_and_receive(channel, "login", %{"user_id" => user_id}, 100) do
            {:ok, %{"feed" => feed}} -> 
                # Process.flag(:trap_exit, true)
                # args = [state]
                # ts = :rand.uniform(50)
                # args = [ts | args]
                # args = [self() | args]
                # Task.start(__MODULE__, :tweet, args)
                text = "Querying the server for feed for user " <> state[:user_id] <> ". Showing the latest 5 tweeets.. "
                text = concat(feed, 5, text)
                IO.puts text
				send self(), {:start_tweeting, true}
				process(100, feed)
			{:exception, at} -> a = 1
            {:error, %{"reason" => reason}} -> IO.puts(reason)
            :timeout -> a = 1#IO.puts("timeout")
        end
		run(state)
	end

    def get_channel(user_id) do
        {:ok, pid} = PhoenixChannelClient.start_link()
		# :timer.sleep(500)
		# IO.inspect(pid)
		host_name = DB.getData(:metadata, :host_name)
    
        {:ok, socket} = PhoenixChannelClient.connect(pid,
          host: host_name,
          path: "/socket/websocket",
          # params: %{token: "something"},
          port: 4000
          # secure: false
          )
		
		# :timer.sleep(500)
		  
        channel = PhoenixChannelClient.channel(socket, "room:" <> user_id, %{})
		# :timer.sleep(500)
		
        case PhoenixChannelClient.join(channel) do
            {:ok, socket} -> a = 1 #IO.puts("Connected")
            {:error, %{"reason" => reason}} -> IO.puts(reason)
            :timeout -> channel = get_channel(user_id)
        end

        channel
    end

    def retweet_probability(c) do
        # if c < 3 do
        #     true
        # else
        #     false
        # end
		# n = :math.pow(2,c) |> round
		# l = Enum.take_random(1..n, 1)
        c = c + 1
		l = Enum.take_random(1..c, 1)
        [head | l] = l
        # IO.puts "head="<> inspect(head) <> ",c" <> inspect(c)
        if to_string(c) == to_string(head) do            
			true
        else
            # IO.puts "head:" <> to_string(head) <> ",c:" <> to_string(c) <> "."
			false
		end
	end

	def tweet(parent_pid, ts, state) do
		
		l = DB.getData(:metadata, :hashtags)
		hs = Enum.take_random(l, 1)
		l1 = getUsers(state[:total_users], 1, state[:id])
		text = random_string()
		in_mid = " "
		text = listToString(hs, text, in_mid)
		text = listToString(l1, text, in_mid <> "@")
		# IO.inspect "tweet generated => " <> text
		user_id = state[:user_id]
		tweet_obj = %{:user_id => user_id, :owner => user_id, :text => text, :hashtags => hs, :mentions => l1, :count => 1}
		# args = [tweet_obj]
		# args = [user_id | args]
		# args = [state[:engine_gen_pid] | args]
		# IO.puts "before sending tweets to engine args " <> inspect(args)
        
        
        # Node.spawn(state[:engine_node], Engine, :tweet, args)

        PhoenixChannelClient.push(state[:channel], "tweet", %{"user_id" => user_id, "tweet_obj" => tweet_obj})
        # case PhoenixChannelClient.push_and_receive(state[:channel], "tweet", %{"user_id" => user_id, "tweet_obj" => tweet_obj}, 100) do
        #     {:ok, map} -> a = 1
        #     {:error, %{"reason" => reason}} -> IO.puts(reason)
        #     :timeout -> a = 1 #IO.puts("timeout")
        # end
    
		
		val = String.slice(user_id, 1..-1) |> Integer.parse |> elem(0)
		
		# if user_id == 'u256' do
		# 	IO.puts "tweet of u256 is " <> inspect(text)
		# end
		:timer.sleep(300)
		if ts > 0 do
			tweet(parent_pid, ts-1, state)
		else 
			# if rem(val, 137) == 0 do
				IO.puts user_id <> " tweeted " <> text
			# end
			send parent_pid, {:logout}
		end
	end

    def concat(list, c, text) do
        # IO.puts inspect(length(list))
		if c == 0 || list == [] do
			text
		else
			[head | list] = list
			text = text <> "\n" <> "Notification: " <> head["text"] <> "  Tweet: \"" <> head["tweet"]["text"] <> "\""
			concat(list, c-1, text)
		end
	end

	def process(c, feed) do
		if c > 0  && feed != [] do
			[head | feed] = feed
			send self(), {:notify, head[:tweet], head[:text]}
			process(c-1, feed)
		end
	end

	def run(state) do
		receive do 
			{"feed", %{"feed" => feed}} -> 
							IO.puts "inside feed for user " <> state[:user_id]
                            # if feed != [] do
                            #     IO.puts "------------------------------------------------------------nor 0"
							# end
							
							Process.flag(:trap_exit, true)
							args = [state]
							ts = :rand.uniform(50)
							args = [ts | args]
							args = [self() | args]
							Task.start(__MODULE__, :tweet, args)
							text = "Querying the server for feed for user " <> state[:user_id] <> ". Showing the latest 5 tweeets.. "
							text = concat(feed, 5, text)
							IO.puts text
                            
                            process(100, feed)
							run(state)
			{:start_tweeting, f} -> # start tweeting 
						if f do
							Process.flag(:trap_exit, true)
							args = [state]
							ts = :rand.uniform(20)
							args = [ts | args]
							args = [self() | args]
							Task.start(__MODULE__, :tweet, args)
						end
						# l = DB.getData(:metadata, :hashtags)
						# hs = Enum.take_random(l, 1)
						# l1 = getUsers(state[:total_users], 1, state[:id])
						# text = random_string()
						# in_mid = " "
						# text = listToString(hs, text, in_mid)
						# text = listToString(l1, text, in_mid <> "@")
						# # IO.inspect "tweet generated => " <> text
						# user_id = state[:user_id]
						# tweet_obj = %{:user_id => user_id, :owner => user_id, :text => text, :hashtags => hs, :mentions => l1}
						# args = [tweet_obj]
						# args = [user_id | args]
						# args = [state[:engine_gen_pid] | args]
						# # IO.puts "before sending tweets to engine args " <> inspect(args)
						# Node.spawn(state[:engine_node], Engine, :tweet, args)
						:timer.sleep(1000)
						run(state)
			{"notify", %{"tweet" => tweet, "text" => text}} -> #IO.puts "inside notify message."
                                        
                                        # {c, _} = tweet["count"] |> Integer.parse
                                        c = tweet["count"]
                                        tweet = Map.put(tweet, "count", c+1)
                                        # IO.puts "count " <> inspect(c)
                                        {c, _} = to_string(c) |> Integer.parse
										if retweet_probability(c) do
                                            # IO.puts "from here---------------------------------"
                                            if c > 4 && c <= 20 do
												if c == 4 do
													IO.puts state[:user_id] <> " retweeted " <> tweet["user_id"] <>  "'s tweet.   Tweet => " <> tweet["text"]
												else 
													IO.puts tweet["user_id"] <> "'s tweet is retweeted " <> to_string(c) <> " times.   Tweet =>" <> tweet["text"]
												end
											end
                                            if c <= 10 do
                                                # if c > 1 do 
                                                #     IO.inspect "Retweet -> " <> tweet["text"] <> " " <> text <> ". This tweeted is retweeted " <> to_string(c) <> " times."
                                                # end
                                                # IO.puts "show here---------------------------------"
												# args = [tweet]
												# args = [state[:user_id] | args]
                                                # args = [state[:engine_gen_pid] | args]
                                                PhoenixChannelClient.push(state[:channel], "retweet", %{"user_id" => state[:user_id], "tweet_obj" => tweet})

                                                # case PhoenixChannelClient.push_and_receive(state[:channel], "retweet", %{:user_id => state[:user_id], :tweet_obj => tweet}, 100) do
                                                #     {:ok, map} -> a = 1
                                                #     {:error, %{"reason" => reason}} -> IO.puts(reason)
                                                #     :timeout -> a = 1 #IO.puts("timeout")
                                                # end

                                                # Node.spawn(state[:engine_node], Engine, :retweet, args)
											end
                                        end
                                        :timer.sleep(1000)
										run(state)

			{:logout} -> 	user_map = %{:user_id => state[:user_id], :password => state[:password]}
							# args = [user_map]
							# args = [state[:engine_gen_pid] | args ]
							# Node.spawn(state[:engine_node], Engine, :logout, args)

                            # PhoenixChannelClient.leave(state[:channel])

							PhoenixChannelClient.push(state[:channel],"logout", %{"user_id" => state[:user_id]} )
							IO.puts state[:user_id] <> " logged out."
							
							ts = :rand.uniform(50)
							:timer.sleep(ts*1000)
							# engine_node = state[:engine_node]
							# engine_gen_pid = state[:engine_gen_pid]
							# gen_pid = state[:gen_pid]
							# curr = state[:id]
							# n = state[:total_users]
							# name = state[:node_name]
							# user_id = state[:user_id]

							# send DB.getData(:metadata, :main_pid), {:login, engine_node, engine_gen_pid, user_id, curr, gen_pid, n, name}

							login_helper(state, state[:user_id])
							
		end
	end

	def listToString(list, res, in_mid) do
		if list == [] do
			res
		else
			[head | list] = list
			listToString(list, res <> in_mid <> to_string(head), in_mid)
		end
	end

	def getUsers(n, c, p) do
		l = Enum.take_random(1..n, c+1)
		solve(l, 0, c, p, [])
	end

	def solve(rem, i, c, p, res) do
		if i == c do
			res
		else
			[u | rem] = rem
			if u == p do
				solve(rem, i, c, p, res)
			else
				res = [ "u" <> to_string(u) | res]
				solve(rem, i+1, c, p, res)
			end
		end
	end

	def hash_sha256(str) do
		:crypto.hash(:sha256, str) |> Base.encode16
	end

	def random_string(n \\ 16, pool \\ "abcdefghijklmnopqrstuvwxyz") do 
        random_string_util("", n, pool)
    end
    def random_string_util(s, n, pool) do
        if n <= 0 do 
            s 
        else 
            size = byte_size(pool)
            random_number = :rand.uniform(size)
            str = s <> String.at(pool, random_number-1)
            random_string_util(str, n-1, pool)
        end
    end

end